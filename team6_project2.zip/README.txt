WHAT
This program takes binary textfiles as input, and outputs 2 files, one which translates the binary instructions into assembley language, and the other which simulates a CPU state, demarcated by cycles.

PUBLISHED
11/11/2018 
v 42

AUTHORS
Anne Leach
Zachary Vasey

INSTRUCTIONS TO RUN
From command line, run team6_project2.py, with the following options (2 required)
	-i 'inputFile.txt'		(This is your chosen binary text file.)
	-o 'intputFile'			(This will name your 2 output files.)
Example:
	python team6_project2.py -i test99_bin.txt -o test99